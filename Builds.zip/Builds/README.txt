There was a sock puppet, and it is dying. Do you have what it takes to keep it alive?
Play through 4 different levels, and try to KEEP IT ALIVE! 
Use the arrow keys (left and right) to select levels, and eat or skip items.

	Left arrow (left, or Eat)
	Right arrow (right, or skip)

Use space when instructed to either pick levels, or return to the main menu.

The timers in the corner are important.
	
	The top time is the Game Time. It tells you how long you have until you win.
	The time on the bottom is yours. If it reaches 0 you lose, but if it goes over the Game Time you win!

Read the pills to see if anything points to death it will kill you.
if you gain an allergy and eat it you die.